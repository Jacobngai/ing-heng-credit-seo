import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';
import vercel from '@astrojs/vercel';
import tailwind from '@astrojs/tailwind';

// Read environment variables for multi-site deployment
// Use build-time vars (without PUBLIC_) first, fallback to runtime vars (with PUBLIC_)
const DEFAULT_LOCALE = process.env.DEFAULT_LOCALE || process.env.PUBLIC_DEFAULT_LOCALE || 'en';
const SITE_URL = process.env.SITE_URL || process.env.PUBLIC_SITE_URL || 'https://ihousing-temp.vercel.app';

// Ensure default locale is first in the array (Astro requirement)
const ALL_LOCALES = ['en', 'zh', 'ms'];
const LOCALES = [DEFAULT_LOCALE, ...ALL_LOCALES.filter(loc => loc !== DEFAULT_LOCALE)];

export default defineConfig({
  site: SITE_URL,
  output: 'static',
  adapter: vercel({
    webAnalytics: {
      enabled: true
    },
    imageService: true,
  }),
  trailingSlash: 'ignore',
  build: {
    format: 'directory',
  },
  integrations: [
    tailwind(),
    sitemap({
      i18n: {
        defaultLocale: DEFAULT_LOCALE,
        locales: {
          en: 'en-MY',
          zh: 'zh-Hans-MY',
          ms: 'ms-MY',
        },
      },
      filter: (page) => {
        // Exclude language selector root page from sitemap
        // Only exclude the exact root URL, not language-prefixed pages
        return page !== `${SITE_URL}/`;
      },
      serialize: (item) => {
        // Add lastmod to all pages
        item.lastmod = new Date();

        // Priority rules for iHousing SEO strategy

        // Homepage variants: 1.0 (highest priority)
        if (item.url.match(/\/(en|zh|ms)\/?$/)) {
          item.priority = 1.0;
          item.changefreq = 'weekly';
        }
        // Parkland Avenue: 0.95 (special project, high priority)
        else if (item.url.includes('/parkland')) {
          item.priority = 0.95;
          item.changefreq = 'weekly';
        }
        // Investment guides: 0.85 (targeting new investors)
        else if (item.url.includes('/invest/')) {
          item.priority = 0.85;
          item.changefreq = 'weekly';
        }
        // Renovation guides: 0.8 (targeting existing owners)
        else if (item.url.includes('/renovation/')) {
          item.priority = 0.8;
          item.changefreq = 'monthly';
        }
        // Comparisons: 0.75 (decision-making content)
        else if (item.url.includes('/compare/')) {
          item.priority = 0.75;
          item.changefreq = 'monthly';
        }
        // For Owners section: 0.9 (primary target audience)
        else if (item.url.includes('/for-owners/')) {
          item.priority = 0.9;
          item.changefreq = 'monthly';
        }
        // Contact page: 0.8 (lead capture)
        else if (item.url.includes('/contact')) {
          item.priority = 0.8;
          item.changefreq = 'monthly';
        }
        // Blog index: 0.7
        else if (item.url.includes('/blog/')) {
          item.priority = 0.7;
          item.changefreq = 'weekly';
        }
        // About page: 0.6
        else if (item.url.includes('/about')) {
          item.priority = 0.6;
          item.changefreq = 'monthly';
        }
        // Default for other pages
        else {
          item.priority = 0.5;
          item.changefreq = 'monthly';
        }

        return item;
      },
    }),
  ],
  i18n: {
    defaultLocale: DEFAULT_LOCALE,
    locales: LOCALES,
    routing: {
      prefixDefaultLocale: true,
      redirectToDefaultLocale: false,
    },
    // Dynamic fallback: only include non-default locales
    // Astro doesn't allow the default locale to be used as a fallback key
    fallback: Object.fromEntries(
      ALL_LOCALES
        .filter(loc => loc !== DEFAULT_LOCALE)
        .map(loc => [loc, DEFAULT_LOCALE])
    ),
  },
  // Image optimization
  image: {
    domains: ['www.ihousing.com.my'],
    remotePatterns: [
      {
        protocol: 'https',
      },
    ],
  },
});
