# GitHub Actions Workflow Diagram

Visual representation of the automated content publishing system.

## Overall System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    AI Content Generation                        │
│                  (ChatGPT, Claude, Custom AI)                   │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Content Input Layer                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │ Manual Input │  │  GitHub API  │  │  CLI Script  │         │
│  │  (Actions)   │  │  (Webhook)   │  │  (ai-pub.js) │         │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘         │
└─────────┼──────────────────┼──────────────────┼─────────────────┘
          │                  │                  │
          └──────────────────┴──────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    GitHub Repository                            │
│                      (Master Branch)                            │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                 Workflow: publish-blog-post.yml                 │
│                                                                 │
│  1. Detect Languages (en, ms, zh)                              │
│  2. Trigger Quality Checks (parallel)                          │
│                                                                 │
│     ┌───────────────┬───────────────┬───────────────┐         │
│     │               │               │               │         │
│     ▼               ▼               ▼               │         │
│  ┌─────┐        ┌─────┐        ┌─────┐             │         │
│  │ EN  │        │ MS  │        │ ZH  │             │         │
│  │Check│        │Check│        │Check│             │         │
│  └──┬──┘        └──┬──┘        └──┬──┘             │         │
│     │              │              │                 │         │
│     └──────────────┴──────────────┘                 │         │
│                    │                                │         │
│  3. Create PR (if checks pass)                      │         │
│  4. Auto-merge (optional)                           │         │
└────────────────────┴────────────────────────────────┘         │
                     │                                           │
                     ▼                                           │
┌─────────────────────────────────────────────────────────────────┐
│                 Workflow: deploy-to-vercel.yml                  │
│                                                                 │
│  Deploy to 3 Vercel Projects (parallel)                        │
│                                                                 │
│  ┌─────────────────┬─────────────────┬─────────────────┐      │
│  │                 │                 │                 │      │
│  ▼                 ▼                 ▼                 │      │
│ ┌───────────┐   ┌───────────┐   ┌───────────┐        │      │
│ │  EN Site  │   │  MS Site  │   │  ZH Site  │        │      │
│ │ Build     │   │ Build     │   │ Build     │        │      │
│ │ & Deploy  │   │ & Deploy  │   │ & Deploy  │        │      │
│ └─────┬─────┘   └─────┬─────┘   └─────┬─────┘        │      │
│       │               │               │              │      │
│       ▼               ▼               ▼              │      │
│  www.ingheng     www.kredit      www.ingheng        │      │
│  credit.com      loan.my          credit.my         │      │
└───────┴───────────────┴───────────────┴──────────────┘      │
        │               │               │                      │
        └───────────────┴───────────────┘                      │
                        │                                       │
                        ▼                                       │
┌─────────────────────────────────────────────────────────────────┐
│                 Workflow: update-sitemaps.yml                   │
│                                                                 │
│  1. Build sitemaps for each language                           │
│  2. Validate XML structure                                     │
│  3. Submit to search engines                                   │
│                                                                 │
│     ┌────────────────┬────────────────┐                       │
│     │                │                │                       │
│     ▼                ▼                ▼                       │
│  ┌─────┐          ┌─────┐          ┌─────┐                  │
│  │Google│          │Bing │          │Other│                  │
│  │Search│          │Web- │          │Search│                 │
│  │Console│         │master│         │Engines│                │
│  └─────┘          └─────┘          └─────┘                  │
└─────────────────────────────────────────────────────────────────┘
```

## Quality Check Workflow (Detailed)

```
┌─────────────────────────────────────────────────────────────────┐
│         Workflow: content-quality-check.yml (Reusable)          │
│                                                                 │
│  Input: file_path, language                                    │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
          ┌──────────────────────────┐
          │  Extract Content         │
          │  - Frontmatter parsing   │
          │  - Keyword extraction    │
          │  - Content cleaning      │
          └────────────┬─────────────┘
                       │
           ┌───────────┴───────────┐
           │                       │
           ▼                       ▼
┌──────────────────┐    ┌──────────────────┐
│ Keyword Density  │    │ Readability      │
│ Check            │    │ Score Check      │
│                  │    │                  │
│ Target: 2-3%     │    │ Target: ≥ 60     │
│                  │    │ (Flesch)         │
│ Status:          │    │                  │
│ ✅ Optimal       │    │ Status:          │
│ ⚠️  Low          │    │ ✅ Good          │
│ ❌ High          │    │ ⚠️  Acceptable   │
└────────┬─────────┘    │ ❌ Too difficult │
         │              └────────┬─────────┘
         │                       │
         ├───────────┬───────────┤
         │           │           │
         ▼           ▼           ▼
  ┌──────────┐ ┌──────────┐ ┌──────────┐
  │  Link    │ │  Fact    │ │ Overall  │
  │Validation│ │Verifica- │ │Evaluation│
  │          │ │  tion    │ │          │
  │ Check    │ │          │ │ Pass/Fail│
  │ URLs     │ │ Company  │ │          │
  │ Return   │ │ Facts    │ │ Generate │
  │ 200/30x  │ │ Present? │ │ Report   │
  └────┬─────┘ └────┬─────┘ └────┬─────┘
       │            │            │
       └────────────┴────────────┘
                    │
                    ▼
         ┌──────────────────────┐
         │  Generate Report     │
         │  - JSON format       │
         │  - Summary metrics   │
         │  - Pass/fail status  │
         └──────────┬───────────┘
                    │
                    ▼
         ┌──────────────────────┐
         │  Post to PR Comment  │
         │  Upload Artifact     │
         │  Set Workflow Output │
         └──────────────────────┘
```

## Publishing Flow (Step by Step)

```
START: New Blog Post Created
         │
         ▼
┌────────────────────┐
│ Trigger Method?    │
└────────┬───────────┘
         │
    ┌────┴─────┬────────────────┐
    │          │                │
    ▼          ▼                ▼
┌────────┐ ┌────────┐      ┌────────┐
│Manual  │ │Git Push│      │API Call│
│Trigger │ │(PR)    │      │(AI)    │
└───┬────┘ └───┬────┘      └───┬────┘
    │          │                │
    └──────────┴────────────────┘
               │
               ▼
    ┌──────────────────────┐
    │ Detect Languages     │
    │ (en, ms, zh)         │
    └──────────┬───────────┘
               │
               ▼
    ┌──────────────────────┐
    │ Run Quality Checks   │
    │ (parallel per lang)  │
    └──────────┬───────────┘
               │
          ┌────┴────┐
          │ Pass?   │
          └────┬────┘
               │
        ┌──────┴──────┐
        │             │
     ✅ YES        ❌ NO
        │             │
        ▼             ▼
   ┌─────────┐   ┌─────────┐
   │Create PR│   │Report   │
   │or Commit│   │Failure  │
   └────┬────┘   │Send     │
        │        │Alert    │
        │        └─────────┘
        ▼
   ┌──────────────┐
   │Auto-merge?   │
   └──────┬───────┘
          │
    ┌─────┴─────┐
    │           │
 ✅ YES      ❌ NO
    │           │
    ▼           ▼
┌────────┐  ┌────────┐
│Auto    │  │Wait for│
│Merge   │  │Manual  │
│        │  │Review  │
└───┬────┘  └───┬────┘
    │           │
    └─────┬─────┘
          │
          ▼
    ┌──────────────┐
    │ Merge to     │
    │ Master       │
    └──────┬───────┘
           │
           ▼
    ┌──────────────────────┐
    │ Trigger Deployment   │
    │ (3 Vercel projects)  │
    └──────────┬───────────┘
               │
        ┌──────┴──────┬──────────┐
        │             │          │
        ▼             ▼          ▼
    ┌──────┐      ┌──────┐   ┌──────┐
    │ EN   │      │ MS   │   │ ZH   │
    │Deploy│      │Deploy│   │Deploy│
    └───┬──┘      └───┬──┘   └───┬──┘
        │             │          │
        └──────┬──────┴──────────┘
               │
               ▼
        ┌──────────────┐
        │ All Success? │
        └──────┬───────┘
               │
          ┌────┴────┐
          │         │
       ✅ YES    ❌ NO
          │         │
          ▼         ▼
    ┌──────────┐ ┌──────────┐
    │Update    │ │Rollback  │
    │Sitemaps  │ │& Alert   │
    └────┬─────┘ └──────────┘
         │
         ▼
    ┌──────────────┐
    │ Submit to    │
    │ Search       │
    │ Engines      │
    └──────┬───────┘
           │
           ▼
       ┌────────┐
       │ DONE ✅ │
       └────────┘
```

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     GitHub Repository                           │
│                   (Single Codebase)                             │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ Same Code
                         │ Different Env Vars
                         │
         ┌───────────────┼───────────────┐
         │               │               │
         ▼               ▼               ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│  Vercel Project │ │  Vercel Project │ │  Vercel Project │
│  (English)      │ │  (Malay)        │ │  (Chinese)      │
│                 │ │                 │ │                 │
│ ENV:            │ │ ENV:            │ │ ENV:            │
│ LOCALE=en       │ │ LOCALE=ms       │ │ LOCALE=zh       │
│ URL=.com        │ │ URL=.my         │ │ URL=.my         │
│                 │ │                 │ │                 │
│ prj_Fyoz...     │ │ prj_eKJt...     │ │ prj_z3Fq...     │
└────────┬────────┘ └────────┬────────┘ └────────┬────────┘
         │                   │                   │
         ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│ Production URL  │ │ Production URL  │ │ Production URL  │
│                 │ │                 │ │                 │
│ www.ingheng     │ │ www.kredit      │ │ www.ingheng     │
│ credit.com      │ │ loan.my         │ │ credit.my       │
│                 │ │                 │ │                 │
│ Domain: EN      │ │ Domain: MS      │ │ Domain: ZH      │
└─────────────────┘ └─────────────────┘ └─────────────────┘
         │                   │                   │
         └───────────────────┴───────────────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │ Google Search   │
                    │ Console         │
                    │                 │
                    │ - 3 Properties  │
                    │ - 3 Sitemaps    │
                    │ - Auto-submit   │
                    └─────────────────┘
```

## Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    Content Creation                             │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
                 [Blog Post .astro]
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Quality Analysis                              │
│                                                                 │
│  Extract:                                                       │
│  - Frontmatter (keywords, metadata)                            │
│  - Content (clean text)                                        │
│  - Links (internal & external)                                 │
│                                                                 │
│  Analyze:                                                       │
│  - Keyword density (2-3%)                                      │
│  - Readability (Flesch ≥ 60)                                   │
│  - Link validity                                               │
│  - Fact presence                                               │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
                  [Quality Report]
                  {
                    passed: true/false,
                    keyword_density: {...},
                    readability: {...},
                    links: {...},
                    facts: {...}
                  }
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Build Process                                 │
│                                                                 │
│  For each language (en, ms, zh):                               │
│  1. Set environment variables                                  │
│  2. Run Astro build                                            │
│  3. Generate sitemap                                           │
│  4. Optimize assets                                            │
│  5. Create deployment package                                  │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
                 [Build Artifacts]
                  dist/
                  ├── index.html
                  ├── en/blog/post.html
                  ├── sitemap-index.xml
                  └── assets/
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Deployment                                    │
│                                                                 │
│  Upload to Vercel:                                             │
│  - Deploy static files                                         │
│  - Configure routing                                           │
│  - Set headers                                                 │
│  - Verify deployment                                           │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
                 [Live Website]
                  https://www.inghengcredit.com
                  https://www.kreditloan.my
                  https://www.inghengcredit.my
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                   SEO Submission                                │
│                                                                 │
│  Submit sitemap to:                                            │
│  - Google Search Console (HTTP ping)                           │
│  - Bing Webmaster (HTTP ping)                                 │
│  - Other search engines                                        │
└─────────────────────────────────────────────────────────────────┘
```

## Error Handling

```
┌─────────────────────────────────────────────────────────────────┐
│                    Error Detection                              │
└────────────────────────┬────────────────────────────────────────┘
                         │
                ┌────────┴────────┐
                │                 │
                ▼                 ▼
        ┌───────────────┐  ┌───────────────┐
        │Quality Check  │  │Build/Deploy   │
        │Failed         │  │Failed         │
        └───────┬───────┘  └───────┬───────┘
                │                  │
                ▼                  ▼
        ┌───────────────┐  ┌───────────────┐
        │1. Log error   │  │1. Log error   │
        │2. Create      │  │2. Rollback    │
        │   comment     │  │3. Alert team  │
        │3. Block merge │  │4. Create      │
        │4. Request fix │  │   issue       │
        └───────┬───────┘  └───────┬───────┘
                │                  │
                └────────┬─────────┘
                         │
                         ▼
                ┌─────────────────┐
                │ Notification    │
                │ System          │
                │                 │
                │ - GitHub PR     │
                │ - Email (opt)   │
                │ - Slack (opt)   │
                └─────────────────┘
```

---

**Legend**:
- ✅ Success path
- ❌ Failure path
- ⚠️  Warning/Alert
- 🔄 Automated process
- 👤 Manual intervention required

---

*This diagram represents the complete automation workflow for the Ing Heng Credit multi-language website. All processes are automated unless marked for manual intervention.*
